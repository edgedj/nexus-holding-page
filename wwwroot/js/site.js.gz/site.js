function startParticles() {
    particlesJS.load('particles-js', '/js/particles.json', function () {
        console.log('particles.json loaded...');
    });
}